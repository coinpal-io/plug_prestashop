<?php

class CoinpalpaymentValidationModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        $cart = $this->context->cart;

        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'coinpalpayment') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            die($this->module->l('This payment method is not available.', 'coinpalpayment'));
        }
        $amount = (float)$cart->getOrderTotal(true, Cart::BOTH);

        $this->module->validateOrder(
            (int) $cart->id,
            Configuration::get('PS_OS_PREPARATION'),
            $amount,
            $module['name'],
            null,
            [],
            null,
            false,
            $cart->secure_key
        );

        $id_order = Order::getOrderByCartId($cart->id);
        $order = new Order($id_order);
        $payment = $order->getOrderPayments();
        $payment[0]->save();

        $customer = new Customer($cart->id_customer);

        if (!Validate::isLoadedObject($customer)) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $currency = $this->context->currency;

        $merchant_no = Configuration::get('COINPALPAYMENT_MERCHANT_NO');
        $secret_key = Configuration::get('COINPALPAYMENT_SECRET_KEY');
        $request_id = 'RE' . $id_order ;
        $order_no = 'OR' . $id_order ;
        $param = [
            'version' => '2',
            'requestId' => $request_id,
            'merchantNo' => $merchant_no,
            'orderNo' => $order_no,
            'orderCurrencyType' => 'fiat',
            'orderCurrency' => $currency->iso_code,
            'orderAmount' => $amount,
            'notifyURL' => $this->context->link->getModuleLink($this->module->name, 'notification', [], true),
            'redirectURL' => $this->context->link->getPageLink('order-confirmation', true, null, "id_cart={$cart->id}&id_module={$this->module->id}&id_order={$order_no}&key={$customer->secure_key}"),
        ];

        $param['sign'] = hash("sha256",
            $secret_key.
            $param['requestId'].
            $param['merchantNo'].
            $param['orderNo'].
            $param['orderAmount'].
            $param['orderCurrency']
        );

        $url = "https://pay.coinpal.io/gateway/pay/checkout";
        $order_data = $this->curlRequest($url, $param);

        // Handle the response and redirect to the payment page
        if ($order_data) {
            $response = json_decode($order_data, true);
            if (isset($response['nextStepContent']) && $response['respCode'] == 200) {
                Tools::redirect($response['nextStepContent']);
            } else {
                // Handle error in response
                $this->errors[] = $this->module->l('Error in payment gateway response: ' . $response['respMessage']);
                $this->redirectWithNotifications('index.php?controller=order&step=1');
            }
        } else {
            // Handle cURL error
            $this->errors[] = $this->module->l('Error in connecting to payment gateway');
            $this->redirectWithNotifications('index.php?controller=order&step=1');
        }
    }

    private function curlRequest($url, $data)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        $result = curl_exec($ch);
        if ($result === false) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}
