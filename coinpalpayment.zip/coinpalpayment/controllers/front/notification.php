<?php

class CoinpalpaymentNotificationModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        // 获取异步通知数据
        $notifyData = Tools::getAllValues();
        // 获取配置的 Secret Key
        $secretKey = Configuration::get('COINPALPAYMENT_SECRET_KEY');
        if (empty($notifyData['requestId'])) {
            die('requestId empty');
        }
        // 验证通知数据
        if ($this->isValid($notifyData, $secretKey)) {
            // 验证成功，处理订单逻辑
            $orderId = substr($notifyData['orderNo'],2);
            $payStatus = $notifyData['status'];
            $order = new Order($orderId);
            if (!Validate::isLoadedObject($order) || $order->current_state == Configuration::get('PS_OS_PAYMENT')) {
                // 无效的订单或已支付成功 不需要更新状态
                die('failure');
            }
            if ($payStatus == 'paid') {
                // 更新订单状态为支付成功
                $order->setCurrentState(Configuration::get('PS_OS_PAYMENT'));
            } else if ($payStatus == 'partial_paid') {
                $order->setCurrentState(Configuration::get('PS_CHECKOUT_STATE_PARTIALLY_PAID'));
            } else {
                if ($order->current_state != Configuration::get('PS_CHECKOUT_STATE_PARTIALLY_PAID')) {
                    if ($payStatus == 'failed') {
                        $order->setCurrentState(Configuration::get('PS_OS_ERROR'));
                    } else if ($payStatus == 'unpaid') {
                        $order->setCurrentState(Configuration::get('PS_OS_OUTOFSTOCK_UNPAID'));
                    } else {
                        $order->setCurrentState(Configuration::get('PS_CHECKOUT_STATE_PENDING'));
                    }
                }
            }
            die('success');
        }
        // 验证失败或处理失败，响应给支付网关
        die('failure');
    }

    private function isValid($notifyData = [], $secretKey = '')
    {
        if (empty($notifyData) || empty($secretKey)) {
            return false;
        }

        $str = $secretKey . $notifyData['requestId'] . $notifyData['merchantNo'] . $notifyData['orderNo'] . $notifyData['orderAmount'] . $notifyData['orderCurrency'];
        $sign = hash('sha256', $str);

        return $sign === $notifyData['sign'];
    }
}
