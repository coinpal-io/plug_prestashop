<?php

if (!defined('_PS_VERSION_')) {
    exit;
}


class coinpalpayment extends PaymentModule
{

    public function __construct()
    {
        $this->name = 'coinpalpayment';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'CoinPal Payment';
        $this->need_instance = 1;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();
        $this->displayName = $this->l('CoinPal Payment');
        $this->description = $this->l('Description of CoinPal Payment module.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('paymentReturn') &&
            Configuration::updateValue('COINPALPAYMENT_MERCHANT_NO', '') &&
            Configuration::updateValue('COINPALPAYMENT_SECRET_KEY', '') &&
            Configuration::updateValue('COINPALPAYMENT_DISPLAY_NAME', 'Pay by CoinPal');
//            &&
//            Configuration::updateValue('COINPALPAYMENT_LOGO', '') &&
//            Configuration::updateValue('COINPALPAYMENT_ACCESS_TOKEN', '');
    }

    public function uninstall()
    {
        return parent::uninstall() &&
            Configuration::deleteByName('COINPALPAYMENT_MERCHANT_NO') &&
            Configuration::deleteByName('COINPALPAYMENT_SECRET_KEY') &&
            Configuration::deleteByName('COINPALPAYMENT_DISPLAY_NAME');
//            &&
//            Configuration::deleteByName('COINPALPAYMENT_LOGO') &&
//            Configuration::deleteByName('COINPALPAYMENT_ACCESS_TOKEN');
    }

    public function getContent()
    {
        $output = null;

        if (Tools::isSubmit('submitCoinpalpaymentModule')) {
            $merchant_no = strval(Tools::getValue('COINPALPAYMENT_MERCHANT_NO'));
            $secret_key = strval(Tools::getValue('COINPALPAYMENT_SECRET_KEY'));
            $display_name = strval(Tools::getValue('COINPALPAYMENT_DISPLAY_NAME'));
//            $access_token = strval(Tools::getValue('COINPALPAYMENT_ACCESS_TOKEN'));
            if (!$merchant_no || empty($merchant_no) || !Validate::isGenericName($merchant_no) ||
                !$secret_key || empty($secret_key) || !Validate::isGenericName($secret_key) ||
                !$display_name || empty($display_name) || !Validate::isGenericName($display_name)
//                || !$access_token || empty($access_token) || !Validate::isGenericName($access_token)
            ) {
                $output .= $this->displayError($this->l('Invalid Configuration value'));
            } else {
                Configuration::updateValue('COINPALPAYMENT_MERCHANT_NO', $merchant_no);
                Configuration::updateValue('COINPALPAYMENT_SECRET_KEY', $secret_key);
                Configuration::updateValue('COINPALPAYMENT_DISPLAY_NAME', $display_name);
//                Configuration::updateValue('COINPALPAYMENT_ACCESS_TOKEN', $access_token);

                // Handle file upload

                if (isset($_FILES['COINPALPAYMENT_LOGO']) && !empty($_FILES['COINPALPAYMENT_LOGO']['tmp_name'])) {
                    $ext = pathinfo($_FILES['COINPALPAYMENT_LOGO']['name'], PATHINFO_EXTENSION);
                    $file_name = 'coinpalpayment_logo.' . $ext;
                    $file_path = _PS_MODULE_DIR_ . $this->name . '/' . $file_name;
                    if (move_uploaded_file($_FILES['COINPALPAYMENT_LOGO']['tmp_name'], $file_path)) {
                        Configuration::updateValue('COINPALPAYMENT_LOGO', $file_name);
                    } else {
                        $output .= $this->displayError($this->l('Logo upload failed'));
                    }
                }

                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }


        return $output . $this->displayForm();
    }

    public function displayForm()
    {
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $fields_form = array();

        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Settings'),
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Merchant No'),
                    'name' => 'COINPALPAYMENT_MERCHANT_NO',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Secret Key'),
                    'name' => 'COINPALPAYMENT_SECRET_KEY',
                    'size' => 20,
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Payment Display Name'),
                    'name' => 'COINPALPAYMENT_DISPLAY_NAME',
                    'size' => 50,
                    'required' => true
                ),
//                array(
//                    'type' => 'text',
//                    'label' => $this->l('Access Token'),
//                    'name' => 'COINPALPAYMENT_ACCESS_TOKEN',
//                    'size' => 50,
//                    'required' => true
//                ),
//                array(
//                    'type' => 'file',
//                    'label' => $this->l('Payment Logo'),
//                    'name' => 'COINPALPAYMENT_LOGO',
//                    'display_image' => true,
//                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->title = $this->displayName;
        $helper->submit_action = 'submitCoinpalpaymentModule';
        $helper->fields_value['COINPALPAYMENT_MERCHANT_NO'] = Configuration::get('COINPALPAYMENT_MERCHANT_NO');
        $helper->fields_value['COINPALPAYMENT_SECRET_KEY'] = Configuration::get('COINPALPAYMENT_SECRET_KEY');
        $helper->fields_value['COINPALPAYMENT_DISPLAY_NAME'] = Configuration::get('COINPALPAYMENT_DISPLAY_NAME');
//        $helper->fields_value['COINPALPAYMENT_ACCESS_TOKEN'] = Configuration::get('COINPALPAYMENT_ACCESS_TOKEN');

        return $helper->generateForm($fields_form);
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        $payment_options = [
            $this->getExternalPaymentOption(),
        ];

        return $payment_options;
    }

    public function getExternalPaymentOption()
    {
        $payment_option = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $display_name = Configuration::get('COINPALPAYMENT_DISPLAY_NAME');
        $logo = Configuration::get('COINPALPAYMENT_LOGO');

        $payment_option->setCallToActionText($this->l($display_name))
            ->setAction($this->context->link->getModuleLink($this->name, 'validation', [], true))
//            ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/' . $logo))
            ->setAdditionalInformation($this->context->smarty->fetch('module:coinpalpayment/views/templates/front/payment_infos.tpl'));

        return $payment_option;
    }
}
